# QuizGenertor — Crossword & Quiz Studio

Responsive crossword va quiz yaratish web-ilovasi. Canva/PowerPoint ruhidagi interfeys, Node.js + Express backend va SQLite ma’lumotlar bazasidan foydalanadi.

## Talablar
- Node.js 18 yoki undan yangi
- npm

## O‘rnatish

```bash
npm install
npm start
```

Brauzerda `http://localhost:3000` manzilini oching.

## Imkoniyatlar
- Savol-javoblardan avtomatik krossvord yaratish
- Krossvordni SQLite bazasiga saqlash
- Krossvordni chop etish / PDF sifatida saqlash (brauzer Print → Save as PDF)
- PowerPoint `.pptx` eksporti
- To‘rt variantli quiz yaratish va to‘g‘ri javobni belgilash
- Quizlarni SQLite bazasiga saqlash
- Responsive desktop, tablet va mobile interfeys

## Papkalar
- `server/` — Express API va SQLite
- `server/services/crossword.js` — krossvord joylashtirish algoritmi
- `public/` — frontend, CSS va JavaScript

## API
- `GET /api/health`
- `POST /api/crosswords/generate`
- `POST /api/crosswords`
- `GET /api/crosswords`
- `GET /api/crosswords/:id`
- `POST /api/quizzes`
- `GET /api/quizzes`
- `GET /api/quizzes/:id`
- `DELETE /api/quizzes/:id`

## Eslatma
Bu boshlang‘ich MVP. Canva bilan bevosita integratsiya yoki Canva hisobiga dizayn yuborish kiritilmagan; uning o‘rniga Canva uslubidagi editor interfeysi ishlatilgan. PPTX eksporti brauzerda internet orqali PptxGenJS modulini yuklaydi.
