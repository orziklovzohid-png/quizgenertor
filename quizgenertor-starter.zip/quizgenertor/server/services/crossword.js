function cleanWord(value) {
  return String(value || '').toLocaleUpperCase('uz-UZ')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^A-ZА-ЯЁЎҚҒҲ0-9]/g, '');
}

function generateCrossword(entries) {
  const words = entries.map((item, index) => ({
    number: index + 1,
    answer: cleanWord(item.answer),
    clue: String(item.clue || '').trim()
  })).filter(item => item.answer.length >= 2 && item.clue);

  if (words.length < 2) throw new Error('Kamida 2 ta to‘g‘ri savol-javob kerak.');

  const size = Math.max(25, ...words.map(w => w.answer.length + 10));
  const grid = Array.from({ length: size }, () => Array(size).fill(''));
  const placed = [];

  // First word goes horizontally through the center.
  const first = words[0];
  const startRow = Math.floor(size / 2);
  const startCol = Math.floor((size - first.answer.length) / 2);
  place(first, startRow, startCol, 'across');

  function place(word, row, col, direction) {
    for (let i = 0; i < word.answer.length; i++) {
      const r = row + (direction === 'down' ? i : 0);
      const c = col + (direction === 'across' ? i : 0);
      grid[r][c] = word.answer[i];
    }
    placed.push({ number: word.number, clue: word.clue, answer: word.answer,
      row, col, direction });
  }

  for (const word of words.slice(1)) {
    let found = false;
    // Find a shared letter with an already placed word.
    for (const existing of placed) {
      for (let i = 0; i < word.answer.length && !found; i++) {
        for (let j = 0; j < existing.answer.length && !found; j++) {
          if (word.answer[i] !== existing.answer[j]) continue;
          const direction = existing.direction === 'across' ? 'down' : 'across';
          const row = existing.row + (existing.direction === 'down' ? j : 0)
            - (direction === 'down' ? i : 0);
          const col = existing.col + (existing.direction === 'across' ? j : 0)
            - (direction === 'across' ? i : 0);
          if (canPlace(word.answer, row, col, direction)) {
            place(word, row, col, direction);
            found = true;
          }
        }
      }
    }
    // If no crossing exists, place the word in a free horizontal row.
    if (!found) {
      for (let row = 1; row < size - 1 && !found; row++) {
        const col = 1;
        if (canPlace(word.answer, row, col, 'across', true)) {
          place(word, row, col, 'across');
          found = true;
        }
      }
    }
  }

  function canPlace(answer, row, col, direction, allowSeparate = false) {
    if (row < 1 || col < 1 ||
        row + (direction === 'down' ? answer.length : 0) >= size - 1 ||
        col + (direction === 'across' ? answer.length : 0) >= size - 1) return false;
    let intersections = 0;
    for (let i = 0; i < answer.length; i++) {
      const r = row + (direction === 'down' ? i : 0);
      const c = col + (direction === 'across' ? i : 0);
      const cell = grid[r][c];
      if (cell && cell !== answer[i]) return false;
      if (cell === answer[i]) intersections++;
      const before = direction === 'across' ? grid[r - 1][c] : grid[r][c - 1];
      const after = direction === 'across' ? grid[r + 1][c] : grid[r][c + 1];
      if (!cell && (before || after)) return false;
    }
    return intersections > 0 || placed.length === 0 || allowSeparate;
  }

  const used = [];
  placed.forEach(p => {
    for (let i = 0; i < p.answer.length; i++) {
      used.push({ r: p.row + (p.direction === 'down' ? i : 0),
        c: p.col + (p.direction === 'across' ? i : 0) });
    }
  });
  const minR = Math.min(...used.map(x => x.r));
  const maxR = Math.max(...used.map(x => x.r));
  const minC = Math.min(...used.map(x => x.c));
  const maxC = Math.max(...used.map(x => x.c));
  const cells = grid.slice(minR, maxR + 1).map(row => row.slice(minC, maxC + 1));
  const starts = placed.map(p => ({ number: p.number, row: p.row - minR,
    col: p.col - minC, direction: p.direction, clue: p.clue, answer: p.answer }));
  return { cells, starts, width: maxC - minC + 1, height: maxR - minR + 1 };
}

module.exports = { generateCrossword };
