const express = require('express');
const cors = require('cors');
const path = require('path');
const Database = require('better-sqlite3');
const { generateCrossword } = require('./services/crossword');

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(path.join(__dirname, 'database.sqlite'));

app.use(cors());
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

db.exec(`
  CREATE TABLE IF NOT EXISTS crosswords (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    entries TEXT NOT NULL,
    puzzle TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS quizzes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    questions TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
`);

app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));

app.post('/api/crosswords/generate', (req, res) => {
  try {
    const { title = 'Yangi krossvord', entries } = req.body;
    if (!Array.isArray(entries) || entries.length < 2) {
      return res.status(400).json({ error: 'Kamida 2 ta savol-javob kiriting.' });
    }
    const puzzle = generateCrossword(entries);
    res.json({ title, puzzle });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.post('/api/crosswords', (req, res) => {
  const { title, entries, puzzle } = req.body;
  if (!title || !Array.isArray(entries) || !puzzle) {
    return res.status(400).json({ error: 'Krossvord ma’lumotlari to‘liq emas.' });
  }
  const result = db.prepare(
    'INSERT INTO crosswords (title, entries, puzzle) VALUES (?, ?, ?)'
  ).run(title, JSON.stringify(entries), JSON.stringify(puzzle));
  res.status(201).json({ id: result.lastInsertRowid });
});

app.get('/api/crosswords', (_req, res) => {
  const rows = db.prepare('SELECT id, title, created_at FROM crosswords ORDER BY id DESC').all();
  res.json(rows);
});

app.get('/api/crosswords/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM crosswords WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Topilmadi.' });
  res.json({ ...row, entries: JSON.parse(row.entries), puzzle: JSON.parse(row.puzzle) });
});

app.post('/api/quizzes', (req, res) => {
  const { title, questions } = req.body;
  if (!title || !Array.isArray(questions) || !questions.length) {
    return res.status(400).json({ error: 'Quiz nomi va savollar kerak.' });
  }
  const result = db.prepare('INSERT INTO quizzes (title, questions) VALUES (?, ?)')
    .run(title, JSON.stringify(questions));
  res.status(201).json({ id: result.lastInsertRowid });
});

app.get('/api/quizzes', (_req, res) => {
  res.json(db.prepare('SELECT id, title, created_at FROM quizzes ORDER BY id DESC').all());
});

app.get('/api/quizzes/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM quizzes WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Topilmadi.' });
  res.json({ ...row, questions: JSON.parse(row.questions) });
});

app.delete('/api/quizzes/:id', (req, res) => {
  db.prepare('DELETE FROM quizzes WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));
app.listen(PORT, () => console.log(`QuizGenertor: http://localhost:${PORT}`));
