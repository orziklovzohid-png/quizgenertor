const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];
let currentPuzzle = null;
let currentEntries = [];
let currentQuiz = [];
let quizMode = 'edit';

function toast(message) {
  const el = $('#toast'); el.textContent = message; el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2500);
}
async function api(url, options = {}) {
  const response = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...options });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Xatolik yuz berdi');
  return data;
}
function showView(name) {
  $$('.view').forEach(v => v.classList.toggle('active', v.id === `${name}View`));
  $$('.nav-item').forEach(v => v.classList.toggle('active', v.dataset.view === name));
  const labels = { home: 'Bosh sahifa', crossword: 'Crossword yaratish', quiz: 'Quiz yaratish', library: 'Saqlangan ishlar' };
  $('#crumb').textContent = labels[name];
  $('#sidebar').classList.remove('open');
  if (name === 'home' || name === 'library') refreshLibrary();
}
document.addEventListener('click', e => {
  const target = e.target.closest('[data-view]');
  if (target) showView(target.dataset.view);
});
$('#menuBtn').addEventListener('click', () => $('#sidebar').classList.toggle('open'));

function addEntry(clue = '', answer = '') {
  const row = document.createElement('div'); row.className = 'entry-row';
  row.innerHTML = `<label>SAVOL VA JAVOB</label><input class="entry-input clue-input" placeholder="Savol / ta’rif" value="${escapeHtml(clue)}"><input class="entry-input answer-input" placeholder="Javob" value="${escapeHtml(answer)}"><button class="remove-btn" title="O‘chirish">×</button>`;
  row.querySelector('.remove-btn').onclick = () => row.remove();
  $('#entries').append(row);
}
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
$('#addEntry').onclick = () => addEntry();
addEntry('Ilmiy ma’lumotlarni tahlil qilish usuli', 'ANALIZ');
addEntry('Ma’lumotlar to‘plami', 'BAZA');
addEntry('Savolga javob topish jarayoni', 'IZLANISH');
addEntry('Bilimni tekshirish vositasi', 'TEST');

$('#generateCrossword').onclick = async () => {
  const entries = $$('.entry-row').map(row => ({
    clue: $('.clue-input', row).value.trim(), answer: $('.answer-input', row).value.trim()
  })).filter(x => x.clue && x.answer);
  if (entries.length < 2) return toast('Kamida 2 ta savol-javob kiriting.');
  try {
    const result = await api('/api/crosswords/generate', { method: 'POST', body: JSON.stringify({ title: $('#crosswordTitle').value, entries }) });
    currentEntries = entries; currentPuzzle = result.puzzle;
    renderCrossword(currentPuzzle);
    $('#saveCrossword').disabled = false;
    $('#crosswordMessage').textContent = `${currentPuzzle.starts.length} ta so‘z joylashtirildi`;
    toast('Krossvord yaratildi!');
  } catch (err) { toast(err.message); }
};

function renderCrossword(puzzle) {
  const starts = new Map(puzzle.starts.map(s => [`${s.row},${s.col}`, s.number]));
  const html = puzzle.cells.map((row, r) => `<tr>${row.map((cell, c) => {
    const number = starts.get(`${r},${c}`);
    return `<td class="${cell ? 'word-cell' : 'empty'}">${cell ? `${number ? `<span class="cell-number">${number}</span>` : ''}` : ''}</td>`;
  }).join('')}</tr>`).join('');
  $('#crosswordCanvas').innerHTML = `<table class="crossword-grid"><tbody>${html}</tbody></table>`;
  const across = puzzle.starts.filter(s => s.direction === 'across');
  const down = puzzle.starts.filter(s => s.direction === 'down');
  const list = (items, title) => `<div><h4>${title}</h4>${items.map(s => `<p><b>${s.number}.</b> ${escapeHtml(s.clue)}</p>`).join('') || '<p>—</p>'}</div>`;
  $('#clues').innerHTML = list(across, 'GORIZONTAL') + list(down, 'VERTIKAL');
}
$('#saveCrossword').onclick = async () => {
  if (!currentPuzzle) return;
  try {
    await api('/api/crosswords', { method: 'POST', body: JSON.stringify({
      title: $('#crosswordTitle').value || 'Krossvord', entries: currentEntries, puzzle: currentPuzzle
    }) });
    toast('Krossvord saqlandi!'); refreshLibrary();
  } catch (err) { toast(err.message); }
};
$('#printCrossword').onclick = () => currentPuzzle ? window.print() : toast('Avval krossvord yarating.');

$('#exportPptx').onclick = async () => {
  if (!currentPuzzle) return toast('Avval krossvord yarating.');
  try {
    const { default: PptxGenJS } = await import('https://cdn.jsdelivr.net/npm/pptxgenjs@3.12.0/+esm');
    const pptx = new PptxGenJS(); pptx.layout = 'LAYOUT_WIDE'; pptx.author = 'QuizGenertor';
    const slide = pptx.addSlide(); slide.background = { color: 'F7F7FB' };
    slide.addText($('#crosswordTitle').value, { x: .5, y: .3, w: 12, h: .5, fontFace: 'Aptos Display', fontSize: 24, bold: true, color: '5144D4' });
    const cell = Math.min(0.35, 5.2 / Math.max(currentPuzzle.width, currentPuzzle.height));
    const startX = (13.33 - currentPuzzle.width * cell) / 2, startY = 1.25;
    currentPuzzle.cells.forEach((row, r) => row.forEach((letter, c) => {
      if (letter) slide.addShape(pptx.ShapeType.rect, { x: startX+c*cell, y: startY+r*cell, w: cell, h: cell, fill: { color: 'FFFFFF' }, line: { color: '6658E8', width: 1 } });
    }));
    slide.addText('Savollar', { x: .8, y: 5.4, w: 2, h: .3, fontSize: 13, bold: true, color: '5144D4' });
    slide.addText(currentPuzzle.starts.map(s => `${s.number}. ${s.clue}`).join('\n'), { x: .8, y: 5.75, w: 11.7, h: 1.2, fontSize: 10, breakLine: false, color: '44445A', valign: 'top' });
    await pptx.writeFile({ fileName: `${($('#crosswordTitle').value || 'crossword').replace(/\s+/g,'_')}.pptx` });
    toast('PowerPoint fayli tayyor!');
  } catch (err) { console.error(err); toast('PPTX eksportida xatolik. Internetni tekshiring.'); }
};

function addQuestion(question = '', options = ['', '', '', ''], correct = 0) {
  const index = currentQuiz.length;
  currentQuiz.push({ question, options, correct });
  renderQuestionForms();
}
function renderQuestionForms() {
  $('#questions').innerHTML = currentQuiz.map((q, i) => `<div class="question-card" data-index="${i}">
    <div class="question-card-head"><b>SAVOL ${i + 1}</b><button class="remove-btn delete-question" data-index="${i}">×</button></div>
    <input class="question-input q-text" placeholder="Savol matnini kiriting" value="${escapeHtml(q.question)}">
    <div class="option-grid">${q.options.map((o, j) => `<div class="option-wrap"><input type="radio" name="correct-${i}" value="${j}" ${q.correct === j ? 'checked' : ''} title="To‘g‘ri javob"><input type="text" class="q-option" data-option="${j}" placeholder="Variant ${j+1}" value="${escapeHtml(o)}"></div>`).join('')}</div>
  </div>`).join('');
  $$('.question-card').forEach(card => {
    const i = Number(card.dataset.index);
    $('.q-text', card).oninput = e => currentQuiz[i].question = e.target.value;
    $$('.q-option', card).forEach(input => input.oninput = e => currentQuiz[i].options[Number(e.target.dataset.option)] = e.target.value);
    $$(`input[name="correct-${i}"]`, card).forEach(input => input.onchange = e => currentQuiz[i].correct = Number(e.target.value));
    $('.delete-question', card).onclick = () => { currentQuiz.splice(i, 1); renderQuestionForms(); renderQuizPreview(); };
  });
  renderQuizPreview();
}
function renderQuizPreview() {
  const valid = currentQuiz.filter(q => q.question.trim());
  $('#quizPreview').innerHTML = valid.length ? valid.map((q, i) => `<div class="preview-question"><h4>${i+1}. ${escapeHtml(q.question)}</h4>${q.options.map((o,j) => `<label class="preview-option"><input type="radio" name="preview-${i}" value="${j}"> ${escapeHtml(o || `Variant ${j+1}`)}</label>`).join('')}</div>`).join('') : `<div class="preview-placeholder"><div>☷</div><b>Quiz preview</b><span>Savol qo‘shganingizda shu yerda chiqadi.</span></div>`;
}
$('#addQuestion').onclick = () => addQuestion();
addQuestion('Ma’lumotlar tahlilining asosiy maqsadi nima?', ['Xulosa chiqarish', 'Rasm chizish', 'Matn terish', 'Fayl o‘chirish'], 0);
addQuestion('SQLite qanday turdagi ma’lumotlar bazasi?', ['Serverless SQL database', 'Grafik muharrir', 'Operatsion tizim', 'Dasturlash tili'], 0);
$('#saveQuiz').onclick = async () => {
  const questions = currentQuiz.filter(q => q.question.trim() && q.options.every(o => o.trim()));
  if (!questions.length) return toast('Kamida bitta to‘liq savol kiriting.');
  try {
    await api('/api/quizzes', { method: 'POST', body: JSON.stringify({ title: $('#quizTitle').value || 'Quiz', questions }) });
    toast('Quiz saqlandi!'); refreshLibrary();
  } catch (err) { toast(err.message); }
};
$('#playQuiz').onclick = () => {
  const answers = currentQuiz.map((q, i) => {
    const selected = $(`input[name="preview-${i}"]:checked`);
    return selected ? Number(selected.value) === q.correct : false;
  });
  const count = answers.filter(Boolean).length;
  $('#quizMessage').textContent = `${count} / ${currentQuiz.length} ta to‘g‘ri javob`;
  toast(`Natija: ${count} / ${currentQuiz.length}`);
};

async function refreshLibrary() {
  try {
    const [crosswords, quizzes] = await Promise.all([api('/api/crosswords'), api('/api/quizzes')]);
    $('#crosswordCount').textContent = crosswords.length;
    $('#quizCount').textContent = quizzes.length;
    const all = [
      ...crosswords.map(x => ({ ...x, type: 'CROSSWORD' })),
      ...quizzes.map(x => ({ ...x, type: 'QUIZ' }))
    ].sort((a,b) => b.id-a.id);
    $('#recentList').innerHTML = all.length ? all.slice(0,5).map(x => `<div class="library-item"><div class="item-type">${x.type}</div><b>${escapeHtml(x.title)}</b><small>${new Date(x.created_at).toLocaleString('uz-UZ')}</small></div>`).join('') : '<div class="empty-state">Hozircha loyihalar yo‘q. Birinchi loyihangizni yarating!</div>';
    $('#libraryContent').innerHTML = all.length ? all.map(x => `<article class="library-item"><div class="item-type">${x.type}</div><b>${escapeHtml(x.title)}</b><small>${new Date(x.created_at).toLocaleString('uz-UZ')}</small></article>`).join('') : '<div class="empty-state">Saqlangan loyihalar mavjud emas.</div>';
  } catch (err) { console.warn(err); }
}
refreshLibrary();
